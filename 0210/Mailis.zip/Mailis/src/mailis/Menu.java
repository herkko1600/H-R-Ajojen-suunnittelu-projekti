package mailis;


import java.util.Scanner;

public class Menu {
    boolean exit;

    public void Menu() {
    }
    
    
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.runMenu();
    }
    
    public void runMenu(){
        printHeader();
        while (!exit){
            printMenu();
            int choice = getInput();
            performAction(choice);
        }
    }

    
  
    private void printHeader(){
        System.out.println("+-------------------------------------------------+");
        System.out.println("|          Tervetuloa!                            |");
        System.out.println("|                 Sa***nan Tunarit...   -Kekkonen |");
        System.out.println("+-------------------------------------------------+");
    }
    
    private void printMenu(){
        System.out.println("Valitse seuraavista vaihtoehdoista: \n");
        System.out.println("1) Syötä ajo ");
        System.out.println("2) Hae ajoja ");
        System.out.println("0) Sulje ohjelma ");
    }
    
    private int getInput(){
        Scanner valinta = new Scanner(System.in);
        int choice = -1;
        while(choice < 0 || choice > 2){
            try {
                
               System.out.println("\nOle hyvä, tee valintasi: ");
               choice = Integer.parseInt(valinta.nextLine());
            }
            catch (NumberFormatException e){
               System.out.println("Väärä valinta, valitse uudelleen");
            }
        }
        return choice;
    }
    private void performAction(int choice){
        switch (choice){
        case 0:
            exit = true;
            System.out.println("Ohjelma suljetaan...");
            break;        
        case 1:
            
        case 2:
        default:
            System.out.println("Tuntematon valinta, valitse uudestaan!");
        }
    }
}